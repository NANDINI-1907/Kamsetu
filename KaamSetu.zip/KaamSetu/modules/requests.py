"""
KaamSetu - Work Request workflow.
Pending -> Accepted/Rejected -> In Progress -> Completed (or Cancelled by customer while Pending).
"""

from database import get_db, now
from modules.deposits import ensure_deposit_requirement, refund_deposits_for_request


def create_request(customer_id, worker_id, category_id, description, location,
                    preferred_date, preferred_time, additional_requirements):
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO work_requests
               (customer_id, worker_id, category_id, description, location, preferred_date,
                preferred_time, additional_requirements, status, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?)""",
            (customer_id, worker_id, category_id, description, location, str(preferred_date),
             str(preferred_time), additional_requirements, now(), now()),
        )
        new_request_id = cur.lastrowid

    # A customer's first-ever booking triggers the one-time ₹200 refundable
    # security deposit requirement. Any later booking is a no-op here since
    # ensure_deposit_requirement() only creates a deposit if none exists yet.
    ensure_deposit_requirement(customer_id, "customer", new_request_id)

    return True, "Work request sent successfully!"


def get_customer_requests(customer_id):
    with get_db() as conn:
        rows = conn.execute(
            """SELECT wr.*, u.name AS worker_name, c.name AS category_name,
                      (SELECT COUNT(*) FROM reviews r WHERE r.request_id = wr.id) AS has_review
               FROM work_requests wr
               JOIN users u ON u.id = wr.worker_id
               LEFT JOIN categories c ON c.id = wr.category_id
               WHERE wr.customer_id = ?
               ORDER BY wr.created_at DESC""",
            (customer_id,),
        ).fetchall()
    return [dict(r) for r in rows]


def get_worker_requests(worker_id, status_filter=None):
    query = """SELECT wr.*, u.name AS customer_name, c.name AS category_name
               FROM work_requests wr
               JOIN users u ON u.id = wr.customer_id
               LEFT JOIN categories c ON c.id = wr.category_id
               WHERE wr.worker_id = ?"""
    params = [worker_id]
    if status_filter:
        query += " AND wr.status = ?"
        params.append(status_filter)
    query += " ORDER BY wr.created_at DESC"
    with get_db() as conn:
        rows = conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


def update_request_status(request_id, worker_id, new_status):
    """Worker updates status of their own request. Enforces valid transitions."""
    valid_transitions = {
        "Pending": {"Accepted", "Rejected"},
        "Accepted": {"In Progress", "Rejected"},
        "In Progress": {"Completed"},
    }
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM work_requests WHERE id = ? AND worker_id = ?",
            (request_id, worker_id),
        ).fetchone()
        if not row:
            return False, "Request not found or access denied."
        current = row["status"]
        if new_status not in valid_transitions.get(current, set()):
            return False, f"Cannot change status from {current} to {new_status}."
        conn.execute(
            "UPDATE work_requests SET status = ?, updated_at = ? WHERE id = ?",
            (new_status, now(), request_id),
        )

    if new_status == "Accepted":
        # A worker's first-ever accepted project triggers the one-time ₹200
        # refundable security deposit requirement (no-op on later projects).
        ensure_deposit_requirement(worker_id, "worker", request_id)
    elif new_status in ("Completed", "Rejected"):
        # Terminal status - refund any Paid deposit tied to this request in
        # full. No penalty math, no partial deductions either way.
        refund_deposits_for_request(request_id)

    return True, f"Request marked as {new_status}."


def cancel_request(request_id, customer_id):
    """Customer can cancel only while still Pending."""
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM work_requests WHERE id = ? AND customer_id = ?",
            (request_id, customer_id),
        ).fetchone()
        if not row:
            return False, "Request not found."
        if row["status"] != "Pending":
            return False, "Only pending requests can be cancelled."
        conn.execute(
            "UPDATE work_requests SET status = 'Cancelled', updated_at = ? WHERE id = ?",
            (now(), request_id),
        )
    # Genuine cancellation - full refund of any Paid deposit tied to this
    # request, no deductions.
    refund_deposits_for_request(request_id)
    return True, "Request cancelled."


def get_all_requests():
    with get_db() as conn:
        rows = conn.execute(
            """SELECT wr.*, cu.name AS customer_name, wo.name AS worker_name, c.name AS category_name
               FROM work_requests wr
               JOIN users cu ON cu.id = wr.customer_id
               JOIN users wo ON wo.id = wr.worker_id
               LEFT JOIN categories c ON c.id = wr.category_id
               ORDER BY wr.created_at DESC"""
        ).fetchall()
    return [dict(r) for r in rows]
