"""KaamSetu - Admin module: full platform oversight and management."""

import streamlit as st
import pandas as pd
import plotly.express as px

from database import get_db
from config import t
from modules.verification import get_pending_verifications, review_verification
from modules.requests import get_all_requests
from modules.reviews import get_all_reviews, hide_review, flag_review
from modules.deposits import get_all_deposits_admin


# ---------------------------------------------------------------------------
# DATA ACCESS
# ---------------------------------------------------------------------------

def get_overview_stats():
    with get_db() as conn:
        total_customers = conn.execute("SELECT COUNT(*) c FROM users WHERE role='customer'").fetchone()["c"]
        total_workers = conn.execute("SELECT COUNT(*) c FROM users WHERE role='worker'").fetchone()["c"]
        verified_workers = conn.execute("SELECT COUNT(*) c FROM workers WHERE verification_status='Verified'").fetchone()["c"]
        pending_verifications = conn.execute("SELECT COUNT(*) c FROM worker_verification WHERE status='Pending'").fetchone()["c"]
        total_requests = conn.execute("SELECT COUNT(*) c FROM work_requests").fetchone()["c"]
        completed_works = conn.execute("SELECT COUNT(*) c FROM work_requests WHERE status='Completed'").fetchone()["c"]
        active_requests = conn.execute(
            "SELECT COUNT(*) c FROM work_requests WHERE status IN ('Pending','Accepted','In Progress')"
        ).fetchone()["c"]
        avg_rating_row = conn.execute("SELECT AVG(rating) a FROM reviews WHERE is_hidden=0").fetchone()
        avg_rating = round(avg_rating_row["a"], 2) if avg_rating_row["a"] else 0.0
    return {
        "total_customers": total_customers, "total_workers": total_workers,
        "verified_workers": verified_workers, "pending_verifications": pending_verifications,
        "total_requests": total_requests, "completed_works": completed_works,
        "active_requests": active_requests, "avg_rating": avg_rating,
    }


def get_all_customers():
    with get_db() as conn:
        rows = conn.execute(
            """SELECT u.*, c.location FROM users u JOIN customers c ON c.user_id = u.id
               ORDER BY u.created_at DESC"""
        ).fetchall()
    return [dict(r) for r in rows]


def get_all_workers():
    with get_db() as conn:
        rows = conn.execute(
            """SELECT u.*, w.verification_status, w.is_trusted, w.availability, w.location,
                      w.main_occupation,
                      (SELECT COUNT(*) FROM work_requests wr WHERE wr.worker_id = u.id AND wr.status='Completed') AS completed_count,
                      (SELECT AVG(rating) FROM reviews r WHERE r.worker_id = u.id AND r.is_hidden=0) AS avg_rating
               FROM users u JOIN workers w ON w.user_id = u.id
               ORDER BY u.created_at DESC"""
        ).fetchall()
    return [dict(r) for r in rows]


def set_user_active(user_id, is_active):
    with get_db() as conn:
        conn.execute("UPDATE users SET is_active = ? WHERE id = ?", (1 if is_active else 0, user_id))


def get_all_categories_admin():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM categories ORDER BY name ASC").fetchall()
    return [dict(r) for r in rows]


def add_category(name):
    name = name.strip()
    if not name:
        return False, "Category name cannot be empty."
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM categories WHERE name = ?", (name,)).fetchone()
        if existing:
            return False, "This category already exists."
        conn.execute("INSERT INTO categories (name, is_active) VALUES (?, 1)", (name,))
    return True, "Category added."


def rename_category(category_id, new_name):
    with get_db() as conn:
        conn.execute("UPDATE categories SET name = ? WHERE id = ?", (new_name.strip(), category_id))


def toggle_category(category_id, is_active):
    with get_db() as conn:
        conn.execute("UPDATE categories SET is_active = ? WHERE id = ?", (1 if is_active else 0, category_id))


# ---------------------------------------------------------------------------
# UI RENDERING
# ---------------------------------------------------------------------------

def render_admin_dashboard(user, lang):
    st.markdown(f"## 🛡️ {t('admin', lang)} {t('dashboard', lang)} — {t('welcome_comma', lang)}, {user['name']}")

    st.session_state.setdefault("admin_page", "overview")

    nav_items = [
        ("overview", "📊", "overview"), ("customers", "👥", "customers"), ("workers", "🧑‍🔧", "workers"),
        ("verification", "🛡️", "verification"), ("requests", "📋", "work_requests"),
        ("reviews", "⭐", "reviews"), ("categories", "🗂️", "categories"),
        ("deposits", "💰", "deposits"),
    ]
    nav = st.columns(len(nav_items))
    for i, (key, icon, label_key) in enumerate(nav_items):
        with nav[i]:
            if st.button(f"{icon} {t(label_key, lang)}", use_container_width=True,
                         type="primary" if st.session_state["admin_page"] == key else "secondary",
                         key=f"adminnav_{key}"):
                st.session_state["admin_page"] = key
                st.rerun()

    st.divider()
    page = st.session_state["admin_page"]

    # Every valid admin sub-page is routed here explicitly; anything
    # unexpected falls back to Overview instead of a blank page.
    if page == "overview":
        _render_overview()
    elif page == "customers":
        _render_customers()
    elif page == "workers":
        _render_workers()
    elif page == "verification":
        _render_verification()
    elif page == "requests":
        _render_requests()
    elif page == "reviews":
        _render_reviews()
    elif page == "categories":
        _render_categories()
    elif page == "deposits":
        _render_deposits()
    else:
        st.session_state["admin_page"] = "overview"
        _render_overview()


def _render_overview():
    stats = get_overview_stats()
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Customers", stats["total_customers"])
    c2.metric("Total Workers", stats["total_workers"])
    c3.metric("Verified Workers", stats["verified_workers"])
    c4.metric("Pending Verifications", stats["pending_verifications"])

    c5, c6, c7, c8 = st.columns(4)
    c5.metric("Total Requests", stats["total_requests"])
    c6.metric("Completed Works", stats["completed_works"])
    c7.metric("Active Requests", stats["active_requests"])
    c8.metric("Avg. Rating", f"{stats['avg_rating']}/5")

    st.divider()
    col1, col2 = st.columns(2)
    with col1:
        requests = get_all_requests()
        if requests:
            df = pd.DataFrame(requests)
            status_counts = df["status"].value_counts().reset_index()
            status_counts.columns = ["Status", "Count"]
            fig = px.pie(status_counts, names="Status", values="Count", title="Work Requests by Status", hole=0.4)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No work requests yet to chart.")
    with col2:
        workers = get_all_workers()
        if workers:
            df = pd.DataFrame(workers)
            v_counts = df["verification_status"].value_counts().reset_index()
            v_counts.columns = ["Status", "Count"]
            fig = px.bar(v_counts, x="Status", y="Count", title="Workers by Verification Status",
                         color="Status")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No workers yet to chart.")

    categories_data = get_all_categories_admin()
    workers = get_all_workers()
    if workers:
        with get_db() as conn:
            rows = conn.execute(
                """SELECT c.name AS category, COUNT(w.user_id) AS worker_count
                   FROM categories c LEFT JOIN workers w ON w.main_category_id = c.id
                   GROUP BY c.id ORDER BY worker_count DESC LIMIT 15"""
            ).fetchall()
        df = pd.DataFrame([dict(r) for r in rows])
        if not df.empty:
            fig = px.bar(df, x="category", y="worker_count", title="Workers per Category (Top 15)")
            st.plotly_chart(fig, use_container_width=True)


def _render_customers():
    st.markdown("### 👥 Manage Customers")
    customers = get_all_customers()
    search = st.text_input("Search by name, email, or phone", key="cust_search")
    if search:
        s = search.lower()
        customers = [c for c in customers if s in c["name"].lower() or s in c["email"].lower() or s in c["phone"]]

    if not customers:
        st.info("No customers found.")
        return

    for c in customers:
        with st.container(border=True):
            col1, col2, col3 = st.columns([3, 2, 1])
            with col1:
                st.markdown(f"**{c['name']}**  ·  {'🟢 Active' if c['is_active'] else '🔴 Deactivated'}")
                st.caption(f"{c['email']} · {c['phone']} · 📍 {c.get('location') or '—'}")
            with col2:
                st.caption(f"Joined: {c['created_at']}")
            with col3:
                if c["is_active"]:
                    if st.button("Deactivate", key=f"deact_cust_{c['id']}"):
                        set_user_active(c["id"], False)
                        st.rerun()
                else:
                    if st.button("Reactivate", key=f"react_cust_{c['id']}"):
                        set_user_active(c["id"], True)
                        st.rerun()


def _render_workers():
    st.markdown("### 🧑‍🔧 Manage Workers")
    workers = get_all_workers()
    search = st.text_input("Search by name, email, or phone", key="worker_search")
    if search:
        s = search.lower()
        workers = [w for w in workers if s in w["name"].lower() or s in w["email"].lower() or s in w["phone"]]

    if not workers:
        st.info("No workers found.")
        return

    for w in workers:
        with st.container(border=True):
            col1, col2, col3 = st.columns([3, 2, 1])
            with col1:
                st.markdown(f"**{w['name']}**  ·  {'🟢 Active' if w['is_active'] else '🔴 Deactivated'}  ·  "
                            f"🛡️ {w['verification_status']}" + (" · 🏆 Trusted" if w["is_trusted"] else ""))
                st.caption(f"{w['email']} · {w['phone']} · 📍 {w.get('location') or '—'}")
                st.caption(f"{w.get('main_occupation') or ''} · ⭐ {round(w['avg_rating'], 1) if w['avg_rating'] else 0}/5 · "
                           f"✅ {w['completed_count']} completed")
            with col2:
                st.caption(f"Joined: {w['created_at']}")
            with col3:
                if w["is_active"]:
                    if st.button("Deactivate", key=f"deact_work_{w['id']}"):
                        set_user_active(w["id"], False)
                        st.rerun()
                else:
                    if st.button("Reactivate", key=f"react_work_{w['id']}"):
                        set_user_active(w["id"], True)
                        st.rerun()


def _render_verification():
    st.markdown("### 🛡️ Verification Management")
    pending = get_pending_verifications()
    if not pending:
        st.info("No pending verification requests.")
        return

    for v in pending:
        with st.container(border=True):
            st.markdown(f"**{v['worker_name']}**  ·  {v['email']} · {v['phone']}")
            st.caption(f"Submitted: {v['submitted_at']}")
            if v.get("note"):
                st.write(v["note"])
            if v.get("document_path"):
                if v["document_path"].lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
                    try:
                        st.image(v["document_path"], width=250)
                    except Exception:
                        st.caption("📄 Document attached")
                else:
                    st.caption(f"📄 Document: {v['document_path']}")
            admin_note = st.text_input("Admin note (optional)", key=f"note_{v['id']}")
            c1, c2 = st.columns(2)
            with c1:
                if st.button("✅ Approve", key=f"approve_{v['id']}", type="primary"):
                    review_verification(v["id"], v["worker_id"], True, admin_note)
                    st.success("Worker verified!")
                    st.rerun()
            with c2:
                if st.button("❌ Reject", key=f"rejectv_{v['id']}"):
                    review_verification(v["id"], v["worker_id"], False, admin_note)
                    st.warning("Verification rejected.")
                    st.rerun()


def _render_requests():
    st.markdown("### 📋 Monitor Work Requests")
    requests = get_all_requests()
    if not requests:
        st.info("No work requests yet.")
        return

    status_filter = st.selectbox("Filter by status",
                                  ["All", "Pending", "Accepted", "In Progress", "Completed", "Rejected", "Cancelled"])
    if status_filter != "All":
        requests = [r for r in requests if r["status"] == status_filter]

    df = pd.DataFrame(requests)[["id", "customer_name", "worker_name", "category_name", "status",
                                 "location", "preferred_date", "created_at"]]
    st.dataframe(df, use_container_width=True, hide_index=True)


def _render_reviews():
    st.markdown("### ⭐ Reviews Monitoring")
    reviews = get_all_reviews()
    if not reviews:
        st.info("No reviews yet.")
        return

    for r in reviews:
        with st.container(border=True):
            flag_text = " 🚩 Flagged" if r["is_flagged"] else ""
            hidden_text = " (Hidden)" if r["is_hidden"] else ""
            st.markdown(f"**{'⭐' * r['rating']}** — {r['customer_name']} → {r['worker_name']}{flag_text}{hidden_text}")
            if r.get("comment"):
                st.write(r["comment"])
            st.caption(r["created_at"])
            c1, c2 = st.columns(2)
            with c1:
                if not r["is_hidden"]:
                    if st.button("🙈 Hide Review", key=f"hide_{r['id']}"):
                        hide_review(r["id"], True)
                        st.rerun()
                else:
                    if st.button("👁️ Unhide Review", key=f"unhide_{r['id']}"):
                        hide_review(r["id"], False)
                        st.rerun()
            with c2:
                if not r["is_flagged"]:
                    if st.button("🚩 Flag as inappropriate", key=f"flag_{r['id']}"):
                        flag_review(r["id"])
                        st.rerun()


def _render_categories():
    st.markdown("### 🗂️ Manage Categories")
    with st.form("add_category_form", clear_on_submit=True):
        new_cat = st.text_input("New category name")
        if st.form_submit_button("➕ Add Category", key="admin_add_category_btn"):
            ok, msg = add_category(new_cat)
            st.success(msg) if ok else st.error(msg)
            st.rerun()

    categories = get_all_categories_admin()
    for c in categories:
        with st.container(border=True):
            col1, col2, col3 = st.columns([3, 1, 1])
            with col1:
                new_name = st.text_input("Name", value=c["name"], key=f"catname_{c['id']}", label_visibility="collapsed")
            with col2:
                if st.button("💾 Rename", key=f"rename_{c['id']}"):
                    rename_category(c["id"], new_name)
                    st.success("Renamed.")
                    st.rerun()
            with col3:
                if c["is_active"]:
                    if st.button("🚫 Disable", key=f"disable_{c['id']}"):
                        toggle_category(c["id"], False)
                        st.rerun()
                else:
                    if st.button("✅ Enable", key=f"enable_{c['id']}"):
                        toggle_category(c["id"], True)
                        st.rerun()


def _render_deposits():
    st.markdown("### 💰 Security Deposits (₹200 Refundable)")
    st.caption("Simple, transparent tracking — no penalty calculations, no partial deductions. "
               "A deposit is refunded in full once its linked booking/project reaches a final status.")

    deposits = get_all_deposits_admin()
    if not deposits:
        st.info("No security deposits recorded yet.")
        return

    status_labels = {"Required": "₹200 Deposit Required", "Paid": "Deposit Paid", "Refunded": "₹200 Refund Processed"}
    refund_labels = {"Required": "Not Applicable", "Paid": "Not Applicable", "Refunded": "Refunded"}

    rows = []
    for d in deposits:
        rows.append({
            "Name": d["user_name"],
            "Role": d["role"].title(),
            "Deposit Amount": f"₹{d['amount']}",
            "Deposit Status": status_labels.get(d["status"], d["status"]),
            "Linked Booking/Project Status": d["request_status"],
            "Refund Status": refund_labels.get(d["status"], "Not Applicable"),
        })

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)

    c1, c2, c3 = st.columns(3)
    c1.metric("Total Deposits", len(deposits))
    c2.metric("Currently Held (Paid)", sum(1 for d in deposits if d["status"] == "Paid"))
    c3.metric("Refunded", sum(1 for d in deposits if d["status"] == "Refunded"))
