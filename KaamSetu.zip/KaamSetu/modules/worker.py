"""KaamSetu - Worker module: professional profile builder + work request handling."""

import streamlit as st

from database import get_db
from config import (
    t, PROFILE_UPLOAD_DIR, CERT_UPLOAD_DIR, PROJECT_UPLOAD_DIR, VIDEO_UPLOAD_DIR,
    VERIFICATION_UPLOAD_DIR, AVAILABILITY_STATES,
)
from utils.helpers import save_uploaded_file
from utils.validation import non_empty
from modules.profile import (
    get_categories, get_worker_full, update_worker_basic, update_availability,
    update_worker_account_info,
    add_skill, get_skills, delete_skill, add_experience, get_experience, delete_experience,
    add_certificate, get_certificates, delete_certificate,
    add_portfolio_project, get_portfolio_projects, delete_portfolio_project,
    render_full_profile,
)
from modules.requests import get_worker_requests, update_request_status
from modules.reviews import get_worker_rating_summary, get_completed_projects_count
from modules.verification import submit_verification, get_worker_verification_history, recompute_trusted_badge
from modules.deposits import get_deposit_for_user, pay_deposit
from auth import change_password


def _derive_worker_notifications(worker_id):
    """Notifications derived from existing tables (work request status changes +
    verification review outcomes) - no schema change needed."""
    with get_db() as conn:
        request_events = conn.execute(
            """SELECT wr.status, wr.updated_at, u.name AS customer_name, c.name AS category_name
               FROM work_requests wr
               JOIN users u ON u.id = wr.customer_id
               LEFT JOIN categories c ON c.id = wr.category_id
               WHERE wr.worker_id = ?
               ORDER BY wr.updated_at DESC LIMIT 15""",
            (worker_id,),
        ).fetchall()
        verification_events = conn.execute(
            """SELECT status, reviewed_at FROM worker_verification
               WHERE worker_id = ? AND reviewed_at IS NOT NULL
               ORDER BY reviewed_at DESC LIMIT 10""",
            (worker_id,),
        ).fetchall()
    events = []
    for r in request_events:
        events.append({"type": "request", "status": r["status"], "when": r["updated_at"],
                        "customer_name": r["customer_name"], "category_name": r["category_name"]})
    for v in verification_events:
        events.append({"type": "verification", "status": v["status"], "when": v["reviewed_at"]})
    events.sort(key=lambda e: e["when"] or "", reverse=True)
    return events[:20]


def render_worker_dashboard(user, lang):
    st.markdown(f"## 👋 {t('welcome_comma', lang)}, {user['name']}")

    worker = get_worker_full(user["id"])
    avg_rating, total_reviews = get_worker_rating_summary(user["id"])
    completed = get_completed_projects_count(user["id"])

    metric_cols = st.columns(4)
    metric_cols[0].metric(f"⭐ {t('rating', lang)}", f"{avg_rating}/5", f"{total_reviews} reviews")
    metric_cols[1].metric(f"✅ {t('completed_projects', lang)}", completed)
    metric_cols[2].metric(f"🛡️ {t('verification', lang)}", worker.get("verification_status", "Not Verified"))
    metric_cols[3].metric("🏆 Trusted Badge", "Yes" if worker.get("is_trusted") else "Not yet")

    st.session_state.setdefault("worker_page", "profile")

    nav_items = [
        ("profile", "🧾", "my_profile"), ("skills", "🧠", "skills"), ("experience", "💼", "experience_label"),
        ("certificates", "📜", "certificates"), ("portfolio", "🖼️", "portfolio"),
        ("requests", "📋", "work_requests"), ("verification", "🛡️", "verification"),
        ("notifications", "🔔", "notifications"), ("settings", "⚙️", "settings"),
        ("preview", "👁️", "preview_public_profile"),
    ]
    nav = st.columns(len(nav_items))
    for i, (key, icon, label_key) in enumerate(nav_items):
        with nav[i]:
            if st.button(f"{icon} {t(label_key, lang)}", use_container_width=True,
                         type="primary" if st.session_state["worker_page"] == key else "secondary",
                         key=f"navbtn_{key}"):
                st.session_state["worker_page"] = key
                st.rerun()

    st.divider()
    page = st.session_state["worker_page"]

    # Every valid worker sub-page is routed here explicitly; anything
    # unexpected falls back to the Profile view instead of a blank page.
    if page == "profile":
        _render_profile_editor(user, worker, lang)
    elif page == "skills":
        _render_skills_editor(user, lang)
    elif page == "experience":
        _render_experience_editor(user, lang)
    elif page == "certificates":
        _render_certificates_editor(user, lang)
    elif page == "portfolio":
        _render_portfolio_editor(user, lang)
    elif page == "requests":
        _render_requests_manager(user, lang)
    elif page == "verification":
        _render_verification_panel(user, worker, lang)
    elif page == "notifications":
        _render_notifications(user, lang)
    elif page == "settings":
        _render_settings(user, lang)
    elif page == "preview":
        render_full_profile(user["id"], lang, viewer_role="worker")
    else:
        st.session_state["worker_page"] = "profile"
        _render_profile_editor(user, worker, lang)


def _render_profile_editor(user, worker, lang):
    st.markdown(f"### 🧾 {t('my_profile', lang)}")
    col1, col2 = st.columns([1, 2])
    with col1:
        if worker.get("profile_photo"):
            try:
                st.image(worker["profile_photo"], width=150)
            except Exception:
                pass
        photo = st.file_uploader("Update profile photo", type=["jpg", "jpeg", "png", "webp"], key="worker_photo")
        if photo and st.button(f"{t('upload', lang)} Photo", key="worker_upload_photo_btn"):
            ok, result = save_uploaded_file(photo, PROFILE_UPLOAD_DIR, "image")
            if ok:
                with get_db() as conn:
                    conn.execute("UPDATE users SET profile_photo = ? WHERE id = ?", (result, user["id"]))
                st.success("Photo updated!")
                st.rerun()
            else:
                st.error(result)

        st.markdown(f"##### {t('availability', lang)}")
        current_avail = worker.get("availability", "Available")
        new_avail = st.selectbox(t("availability", lang), AVAILABILITY_STATES,
                                  index=AVAILABILITY_STATES.index(current_avail) if current_avail in AVAILABILITY_STATES else 0,
                                  key="worker_avail_select")
        if new_avail != current_avail:
            update_availability(user["id"], new_avail)
            st.success(f"Availability set to {new_avail}")
            st.rerun()

    with col2:
        categories = get_categories()
        cat_names = [c["name"] for c in categories]
        with st.form("worker_profile_form"):
            main_occupation = st.text_input("Main occupation / headline",
                                             value=worker.get("main_occupation") or "",
                                             placeholder="e.g. Licensed Residential Electrician")
            default_idx = cat_names.index(worker["main_category_name"]) if worker.get("main_category_name") in cat_names else 0
            main_category = st.selectbox("Main category", cat_names, index=default_idx if cat_names else 0)
            about = st.text_area("About / Bio", value=worker.get("about") or "", height=120,
                                  placeholder="Tell customers about your work, specialties, and approach...")
            worker_location = st.text_input("Your location", value=worker.get("worker_location") or "")
            service_location = st.text_input("Service area (where you work)",
                                              value=worker.get("service_location") or "")
            rate_info = st.text_input("Expected charges / rate (optional)",
                                       value=worker.get("rate_info") or "", placeholder="e.g. ₹500/visit")

            if st.form_submit_button(t("save", lang), type="primary"):
                category_id = next((c["id"] for c in categories if c["name"] == main_category), None)
                update_worker_basic(user["id"], about.strip(), main_occupation.strip(), category_id,
                                     worker_location.strip(), service_location.strip(), rate_info.strip())
                st.success("Profile updated successfully!")
                st.rerun()


def _render_skills_editor(user, lang):
    st.markdown(f"### 🧠 {t('skills', lang)}")
    categories = get_categories()
    cat_names = [c["name"] for c in categories]

    with st.form("add_skill_form", clear_on_submit=True):
        c1, c2, c3 = st.columns([2, 2, 1])
        with c1:
            skill_name = st.text_input("Skill name", placeholder="e.g. House wiring")
        with c2:
            category_choice = st.selectbox("Related category", cat_names) if cat_names else None
        with c3:
            years = st.number_input("Years exp.", min_value=0.0, max_value=50.0, step=0.5)
        if st.form_submit_button(f"➕ {t('add', lang)}"):
            if not non_empty(skill_name):
                st.error("Please enter a skill name.")
            else:
                category_id = next((c["id"] for c in categories if c["name"] == category_choice), None)
                add_skill(user["id"], category_id, skill_name, years)
                st.success("Skill added!")
                st.rerun()

    skills = get_skills(user["id"])
    if not skills:
        st.info(t("no_skills_yet", lang))
    for s in skills:
        c1, c2 = st.columns([5, 1])
        with c1:
            st.markdown(f"- **{s['skill_name']}** ({s.get('category_name') or 'General'}) — "
                        f"{s['years_experience']} yrs")
        with c2:
            if st.button("🗑️", key=f"del_skill_{s['id']}"):
                delete_skill(s["id"], user["id"])
                st.rerun()


def _render_experience_editor(user, lang):
    st.markdown(f"### 💼 {t('experience_label', lang)}")
    with st.form("add_experience_form", clear_on_submit=True):
        title = st.text_input("Role / Title", placeholder="e.g. Senior Electrician")
        organization = st.text_input("Organization / Client (optional)")
        description = st.text_area(t("description", lang))
        c1, c2 = st.columns(2)
        with c1:
            start_date = st.date_input("Start date")
        with c2:
            is_current = st.checkbox("This is my current role")
            end_date = None if is_current else st.date_input("End date")
        if st.form_submit_button(f"➕ {t('add', lang)}"):
            if not non_empty(title):
                st.error("Please enter a role/title.")
            else:
                add_experience(user["id"], title, organization, description, start_date, end_date)
                st.success("Experience added!")
                st.rerun()

    exp_list = get_experience(user["id"])
    if not exp_list:
        st.info(t("no_experience_yet", lang))
    for e in exp_list:
        with st.container(border=True):
            c1, c2 = st.columns([5, 1])
            with c1:
                end = e["end_date"] or "Present"
                st.markdown(f"**{e['title']}** at {e.get('organization') or '—'}  \n_{e['start_date']} → {end}_")
                if e.get("description"):
                    st.write(e["description"])
            with c2:
                if st.button(f"🗑️ {t('delete', lang)}", key=f"del_exp_{e['id']}"):
                    delete_experience(e["id"], user["id"])
                    st.rerun()


def _render_certificates_editor(user, lang):
    st.markdown(f"### 📜 {t('certificates', lang)}")
    with st.form("add_cert_form", clear_on_submit=True):
        c1, c2, c3 = st.columns(3)
        with c1:
            name = st.text_input("Certificate name")
        with c2:
            organization = st.text_input("Issuing organization")
        with c3:
            year = st.number_input("Year", min_value=1980, max_value=2100, step=1, value=2024)
        file = st.file_uploader("Certificate image/document", type=["jpg", "jpeg", "png", "pdf"])
        if st.form_submit_button(f"➕ {t('add', lang)}"):
            if not non_empty(name):
                st.error("Please enter the certificate name.")
            else:
                file_path = None
                if file:
                    ok, result = save_uploaded_file(file, CERT_UPLOAD_DIR, "doc")
                    if not ok:
                        st.error(result)
                        st.stop()
                    file_path = result
                add_certificate(user["id"], name, organization, int(year), file_path)
                st.success("Certificate added!")
                st.rerun()

    certs = get_certificates(user["id"])
    if not certs:
        st.info(t("no_certificates", lang))
    else:
        cols = st.columns(3)
        for i, c in enumerate(certs):
            with cols[i % 3]:
                with st.container(border=True):
                    if c.get("file_path") and c["file_path"].lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
                        try:
                            st.image(c["file_path"], use_container_width=True)
                        except Exception:
                            st.markdown("📄")
                    else:
                        st.markdown("📄 Document")
                    st.markdown(f"**{c['name']}**")
                    st.caption(f"{c.get('organization') or ''} · {c.get('year') or ''}")
                    if st.button(f"🗑️ {t('delete', lang)}", key=f"del_cert_{c['id']}"):
                        delete_certificate(c["id"], user["id"])
                        st.rerun()


def _render_portfolio_editor(user, lang):
    st.markdown(f"### 🖼️ {t('portfolio', lang)}")
    categories = get_categories()
    cat_names = [c["name"] for c in categories]

    with st.form("add_project_form", clear_on_submit=True):
        title = st.text_input("Project title")
        description = st.text_area("Project description")
        c1, c2, c3 = st.columns(3)
        with c1:
            category_choice = st.selectbox("Category", cat_names) if cat_names else None
        with c2:
            location = st.text_input(t("location", lang))
        with c3:
            project_date = st.date_input("Completion date")
        photos = st.file_uploader("Work photos", type=["jpg", "jpeg", "png", "webp"], accept_multiple_files=True)
        video = st.file_uploader("Work video (optional)", type=["mp4", "mov", "webm"])

        if st.form_submit_button(f"➕ {t('add', lang)}"):
            if not non_empty(title):
                st.error("Please enter a project title.")
            else:
                photo_paths = []
                for p in (photos or []):
                    ok, result = save_uploaded_file(p, PROJECT_UPLOAD_DIR, "image")
                    if ok:
                        photo_paths.append(result)
                    else:
                        st.warning(f"Skipped a photo: {result}")
                video_path = None
                if video:
                    ok, result = save_uploaded_file(video, VIDEO_UPLOAD_DIR, "video")
                    if ok:
                        video_path = result
                    else:
                        st.warning(result)
                category_id = next((c["id"] for c in categories if c["name"] == category_choice), None)
                add_portfolio_project(user["id"], title, description, category_id, location,
                                       project_date, video_path, photo_paths)
                st.success("Project added to your portfolio!")
                st.rerun()

    projects = get_portfolio_projects(user["id"])
    if not projects:
        st.info(t("no_portfolio", lang))
    for p in projects:
        with st.container(border=True):
            c1, c2 = st.columns([5, 1])
            with c1:
                st.markdown(f"**{p['title']}** — {p.get('category_name') or ''}")
                st.caption(f"📍 {p.get('location') or '—'} · {p.get('project_date') or ''}")
                if p.get("description"):
                    st.write(p["description"])
                if p.get("media"):
                    media_cols = st.columns(min(4, len(p["media"])))
                    for i, m in enumerate(p["media"]):
                        with media_cols[i % len(media_cols)]:
                            try:
                                st.image(m["file_path"], use_container_width=True)
                            except Exception:
                                pass
            with c2:
                if st.button(f"🗑️ {t('delete', lang)}", key=f"del_proj_{p['id']}"):
                    delete_portfolio_project(p["id"], user["id"])
                    st.rerun()


def _render_deposit_badge(deposit, lang, role, key_prefix, on_paid_rerun=True):
    """Small, reusable ₹200 refundable-deposit status block."""
    if not deposit:
        return
    status = deposit["status"]
    if status == "Required":
        st.warning(f"🔒 {t('deposit_required', lang)}")
        st.caption(t("deposit_note", lang))
        if st.button(f"💳 {t('pay_deposit_button', lang)}", key=f"{key_prefix}pay_deposit_btn"):
            ok, msg = pay_deposit(deposit["user_id"], role)
            if ok:
                st.success(msg)
                if on_paid_rerun:
                    st.rerun()
            else:
                st.error(msg)
    elif status == "Paid":
        st.info(f"🔒 {t('deposit_paid', lang)} (₹{deposit['amount']})")
    elif status == "Refunded":
        st.success(f"🔒 {t('refund_processed', lang)}")


def _render_requests_manager(user, lang):
    st.markdown(f"### 📋 {t('work_requests', lang)}")
    status_options = ["All", "Pending", "Accepted", "In Progress", "Completed", "Rejected", "Cancelled"]
    status_filter = st.selectbox("Filter by status", status_options, key="worker_requests_status_filter")
    requests = get_worker_requests(user["id"], None if status_filter == "All" else status_filter)

    if not requests:
        st.info(t("no_requests_yet", lang))
        return

    deposit = get_deposit_for_user(user["id"], "worker")

    status_colors = {
        "Pending": "🟡", "Accepted": "🔵", "In Progress": "🟠",
        "Completed": "🟢", "Rejected": "🔴", "Cancelled": "⚫",
    }
    for r in requests:
        with st.container(border=True):
            st.markdown(f"**{status_colors.get(r['status'], '')} {r['status']}** — "
                        f"{r.get('category_name') or 'Service'} for **{r['customer_name']}**")
            st.caption(f"📍 {r['location']} · 📅 {r['preferred_date']} {r['preferred_time']}")
            st.write(r["description"])
            if r.get("additional_requirements"):
                st.caption(f"Additional: {r['additional_requirements']}")

            # This is the specific project the worker's one-time ₹200
            # refundable deposit is tied to (if any) - show its status here.
            if deposit and deposit["request_id"] == r["id"]:
                _render_deposit_badge(deposit, lang, "worker", key_prefix=f"workreq_{r['id']}_")

            b1, b2, b3 = st.columns(3)
            if r["status"] == "Pending":
                with b1:
                    if st.button("✅ Accept", key=f"accept_{r['id']}"):
                        update_request_status(r["id"], user["id"], "Accepted")
                        st.rerun()
                with b2:
                    if st.button("❌ Reject", key=f"reject_{r['id']}"):
                        update_request_status(r["id"], user["id"], "Rejected")
                        st.rerun()
            elif r["status"] == "Accepted":
                with b1:
                    if st.button("🚧 Mark In Progress", key=f"progress_{r['id']}"):
                        update_request_status(r["id"], user["id"], "In Progress")
                        st.rerun()
                with b2:
                    if st.button("❌ Reject", key=f"reject2_{r['id']}"):
                        update_request_status(r["id"], user["id"], "Rejected")
                        st.rerun()
            elif r["status"] == "In Progress":
                with b1:
                    if st.button("🏁 Mark Completed", key=f"complete_{r['id']}"):
                        ok, msg = update_request_status(r["id"], user["id"], "Completed")
                        if ok:
                            recompute_trusted_badge(user["id"])
                        st.rerun()


def _render_verification_panel(user, worker, lang):
    st.markdown(f"### 🛡️ {t('verification', lang)}")
    status = worker.get("verification_status", "Not Verified")
    badge_map = {"Verified": "✅ Verified", "Pending": "⏳ Pending Review", "Rejected": "🔴 Rejected", "Not Verified": "⚪ Not Verified"}
    st.markdown(f"**Current status:** {badge_map.get(status, status)}")
    st.caption("Verification is a KaamSetu internal document review process performed by our admin team, "
               "not a government or third-party background check.")

    if status in ("Not Verified", "Rejected"):
        with st.form("verification_form"):
            note = st.text_area("Tell us about your qualifications / ID proof context")
            doc = st.file_uploader("Upload ID/qualification document", type=["jpg", "jpeg", "png", "pdf"])
            if st.form_submit_button("Submit for Verification"):
                doc_path = None
                if doc:
                    ok, result = save_uploaded_file(doc, VERIFICATION_UPLOAD_DIR, "doc")
                    if not ok:
                        st.error(result)
                        st.stop()
                    doc_path = result
                ok, msg = submit_verification(user["id"], doc_path, note)
                st.success(msg)
                st.rerun()
    elif status == "Pending":
        st.info("Your verification request is under review by our admin team.")

    history = get_worker_verification_history(user["id"])
    if history:
        st.markdown("#### Verification History")
        for h in history:
            st.caption(f"{h['submitted_at']} → **{h['status']}**" +
                       (f" ({h['admin_note']})" if h.get("admin_note") else ""))


def _render_notifications(user, lang):
    st.markdown(f"### 🔔 {t('notifications', lang)}")
    events = _derive_worker_notifications(user["id"])
    if not events:
        st.info(t("no_notifications", lang))
        return

    status_icons = {
        "Pending": "🟡", "Accepted": "✅", "In Progress": "🚧",
        "Completed": "🏁", "Rejected": "❌", "Cancelled": "⚫",
        "Verified": "🛡️",
    }
    for e in events:
        icon = status_icons.get(e["status"], "🔔")
        with st.container(border=True):
            if e["type"] == "request":
                st.markdown(f"{icon} Request for **{e.get('category_name') or 'a service'}** from "
                            f"**{e['customer_name']}** is now **{e['status']}**")
            else:
                st.markdown(f"{icon} Your verification status is now **{e['status']}**")
            st.caption(e["when"])


def _render_settings(user, lang):
    st.markdown(f"### ⚙️ {t('settings', lang)}")
    worker = get_worker_full(user["id"])

    st.markdown(f"#### {t('account_info', lang)}")
    with st.form("worker_account_settings_form"):
        name = st.text_input(t("name", lang), value=worker.get("name", ""))
        st.text_input(t("email", lang), value=worker.get("email", ""), disabled=True)
        phone = st.text_input(t("phone", lang), value=worker.get("phone", ""))
        if st.form_submit_button(t("save", lang), type="primary"):
            if not non_empty(name) or not non_empty(phone):
                st.error("Name and phone cannot be empty.")
            else:
                update_worker_account_info(user["id"], name.strip(), phone.strip())
                st.session_state["user"]["name"] = name.strip()
                st.success("Account info updated!")
                st.rerun()

    st.divider()
    st.markdown(f"#### 🔒 {t('security_deposit', lang)}")
    deposit = get_deposit_for_user(user["id"], "worker")
    if not deposit:
        st.caption(t("no_deposit_required_yet_worker", lang))
    else:
        _render_deposit_badge(deposit, lang, "worker", key_prefix="worker_settings_")

    st.divider()
    st.markdown(f"#### {t('change_password', lang)}")
    with st.form("worker_change_password_form"):
        current_password = st.text_input(t("current_password", lang), type="password")
        new_password = st.text_input(t("new_password", lang), type="password")
        confirm_new_password = st.text_input(t("confirm_new_password", lang), type="password")
        if st.form_submit_button(t("change_password", lang), type="primary"):
            if new_password != confirm_new_password:
                st.error("New passwords do not match.")
            else:
                ok, msg = change_password(user["id"], current_password, new_password)
                if ok:
                    st.success(t("password_changed", lang))
                else:
                    st.error(msg)
