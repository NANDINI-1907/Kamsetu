"""
KaamSetu - Smart Worker Matching (rule-based).
This is explicitly a transparent, rule-based scoring system - NOT machine learning /
advanced AI. Weights are simple and explainable so results can be justified to users.

Weight budget (totals 100):
    Skill/category match  = 30
    Location proximity     = 20
    Experience              = 15
    Availability             = 15
    Rating                   = 10
    Completed projects       = 5
    Budget compatibility     = 5
"""

from utils.helpers import haversine_km

WEIGHTS = {
    "skill_match": 30,
    "location": 20,
    "experience": 15,
    "availability": 15,
    "rating": 10,
    "completed_projects": 5,
    "budget": 5,
}

# If the best available match scores below this, the UI shows
# "No exact match found" (with suggestions) instead of presenting it as a
# strong recommendation - but the ranked list is still shown underneath,
# per spec: "Do not show an empty/broken page."
NO_MATCH_THRESHOLD = 40


def _score_skill(worker_row, search_category_id, reasons):
    if not search_category_id:
        return WEIGHTS["skill_match"] * 0.6
    if worker_row.get("main_category_id") == search_category_id:
        reasons.append("Required skill matched")
        return WEIGHTS["skill_match"]
    if worker_row.get("has_skill_in_category"):
        reasons.append("Related skill matched")
        return WEIGHTS["skill_match"] * 0.7
    return 0


def _score_location(worker_row, customer_lat, customer_lon, reasons):
    distance = haversine_km(customer_lat, customer_lon, worker_row.get("lat"), worker_row.get("lon"))
    if distance is not None:
        if distance <= 5:
            reasons.append("Located nearby")
            return WEIGHTS["location"]
        elif distance <= 15:
            reasons.append("Reasonably close location")
            return WEIGHTS["location"] * 0.6
        elif distance <= 40:
            return WEIGHTS["location"] * 0.3
        return WEIGHTS["location"] * 0.1
    # Unknown coordinates: fall back to simple text match on location strings
    loc_text = (worker_row.get("search_location_text") or "").strip().lower()
    worker_loc = (worker_row.get("location") or "").lower()
    if loc_text and worker_loc and loc_text in worker_loc:
        reasons.append("Located nearby")
        return WEIGHTS["location"]
    return WEIGHTS["location"] * 0.4


def _score_experience(worker_row, min_experience_required, reasons):
    exp = worker_row.get("total_experience") or 0
    if min_experience_required and exp >= min_experience_required:
        reasons.append(f"{int(min_experience_required)}+ years experience")
        return WEIGHTS["experience"]
    if not min_experience_required:
        cap = 10
        return WEIGHTS["experience"] * min(1.0, exp / cap)
    if exp > 0:
        return WEIGHTS["experience"] * (exp / max(1, min_experience_required)) * 0.5
    return 0


def _score_availability(worker_row, preferred_availability, urgency, reasons):
    availability = worker_row.get("availability", "Available")
    strict = (urgency == "High")

    if not preferred_availability or preferred_availability == "Any":
        if availability == "Available":
            return WEIGHTS["availability"]
        if availability == "Busy":
            return 0 if strict else WEIGHTS["availability"] * 0.5
        return 0 if strict else WEIGHTS["availability"] * 0.2

    if preferred_availability == "Today":
        if availability == "Available":
            reasons.append("Available today")
            return WEIGHTS["availability"]
        if availability == "Busy":
            return 0 if strict else WEIGHTS["availability"] * 0.3
        return 0

    # Any other custom preference string - Available workers still score fully
    if availability == "Available":
        reasons.append("Available for this schedule")
        return WEIGHTS["availability"]
    return 0 if strict else WEIGHTS["availability"] * 0.3


def _score_rating(worker_row, reasons):
    rating = worker_row.get("avg_rating") or 0
    if rating > 0:
        if rating >= 4.5:
            reasons.append("Highly rated")
        elif rating >= 3.5:
            reasons.append("Well rated")
        return WEIGHTS["rating"] * (rating / 5.0)
    return WEIGHTS["rating"] * 0.3


def _score_completed_projects(worker_row, reasons):
    completed = worker_row.get("completed_projects") or 0
    cap = 20
    if completed > 0:
        reasons.append(f"{completed} completed projects")
    return WEIGHTS["completed_projects"] * min(1.0, completed / cap)


def _score_budget(worker_row, budget_min, budget_max, reasons):
    rate_info = worker_row.get("rate_info") or ""
    if not budget_min and not budget_max:
        return WEIGHTS["budget"] * 0.7
    # rate_info is free text (e.g. "₹500/visit"); we cannot reliably parse it,
    # so budget compatibility is treated as a light, honest signal rather than
    # a hard filter - full credit unless we can clearly tell it's mismatched.
    if rate_info:
        digits = "".join(ch for ch in rate_info if ch.isdigit())
        if digits:
            try:
                rate_value = int(digits[:6])
                if budget_min and budget_max and budget_min <= rate_value <= budget_max:
                    reasons.append("Within your budget")
                    return WEIGHTS["budget"]
                elif budget_max and rate_value > budget_max:
                    return WEIGHTS["budget"] * 0.2
            except ValueError:
                pass
    return WEIGHTS["budget"] * 0.6


def score_worker(worker_row, search_category_id=None, customer_lat=None, customer_lon=None,
                  min_experience_required=0, preferred_availability=None,
                  budget_min=None, budget_max=None, urgency="Medium"):
    """
    Compute a 0-100 match score and human-readable reasons for a single worker row.
    Verified status is checked (a factor customers explicitly care about) and included
    as a bonus reason rather than a separate weight bucket, since the requested 7-factor
    weight table already totals 100.
    """
    reasons = []
    score = 0.0

    skill_score = _score_skill(worker_row, search_category_id, reasons)
    score += skill_score
    score += _score_location(worker_row, customer_lat, customer_lon, reasons)
    score += _score_experience(worker_row, min_experience_required, reasons)
    score += _score_availability(worker_row, preferred_availability, urgency, reasons)
    score += _score_rating(worker_row, reasons)
    score += _score_completed_projects(worker_row, reasons)
    score += _score_budget(worker_row, budget_min, budget_max, reasons)

    if worker_row.get("verification_status") == "Verified":
        reasons.append("Verified worker")
        score = min(100, score + 3)

    score = max(0, min(100, round(score)))
    # A worker whose skill/category does not match at all is never a genuine
    # match, no matter how well other unrelated factors (rating, availability,
    # etc.) happen to score - otherwise an out-of-category worker could
    # cross the "match" threshold purely on unrelated strengths.
    is_category_match = skill_score > 0 or not search_category_id
    return score, reasons, is_category_match


def rank_workers(worker_rows, search_category_id=None, customer_lat=None, customer_lon=None,
                  min_experience_required=0, preferred_availability=None,
                  budget_min=None, budget_max=None, location_text=None, urgency="Medium"):
    """Attach match_score and match_reasons to each worker row dict, sorted descending."""
    if not worker_rows:
        return []
    ranked = []
    for w in worker_rows:
        w = dict(w)
        w["search_location_text"] = location_text
        score, reasons, is_category_match = score_worker(
            w, search_category_id=search_category_id,
            customer_lat=customer_lat, customer_lon=customer_lon,
            min_experience_required=min_experience_required,
            preferred_availability=preferred_availability,
            budget_min=budget_min, budget_max=budget_max,
            urgency=urgency,
        )
        w["match_score"] = score
        w["match_reasons"] = reasons
        w["is_category_match"] = is_category_match
        ranked.append(w)
    ranked.sort(key=lambda x: x["match_score"], reverse=True)
    return ranked


def has_strong_match(ranked_workers):
    """True if the top-ranked worker is both a genuine category match AND
    scores at/above NO_MATCH_THRESHOLD. Used by the UI to decide whether to
    show 'No exact match found' with suggestions."""
    if not ranked_workers:
        return False
    top = ranked_workers[0]
    return top.get("is_category_match", True) and top["match_score"] >= NO_MATCH_THRESHOLD
