"""
KaamSetu - Worker Verification system.
Workers submit documents/info; ONLY Admin can approve/reject. Workers cannot
change their own verification status. Does not claim government/background
verification - this is a KaamSetu-internal document review process.
"""

from database import get_db, now
from config import TRUSTED_WORKER_MIN_COMPLETED_PROJECTS, TRUSTED_WORKER_MIN_RATING


def submit_verification(worker_id, document_path, note):
    with get_db() as conn:
        conn.execute(
            """INSERT INTO worker_verification (worker_id, document_path, note, status, submitted_at)
               VALUES (?, ?, ?, 'Pending', ?)""",
            (worker_id, document_path, note, now()),
        )
        conn.execute(
            "UPDATE workers SET verification_status = 'Pending' WHERE user_id = ?",
            (worker_id,),
        )
    return True, "Verification request submitted. Our team will review it soon."


def get_pending_verifications():
    with get_db() as conn:
        rows = conn.execute(
            """SELECT wv.*, u.name AS worker_name, u.email, u.phone
               FROM worker_verification wv
               JOIN users u ON u.id = wv.worker_id
               WHERE wv.status = 'Pending'
               ORDER BY wv.submitted_at ASC"""
        ).fetchall()
    return [dict(r) for r in rows]


def get_worker_verification_history(worker_id):
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM worker_verification WHERE worker_id = ? ORDER BY submitted_at DESC",
            (worker_id,),
        ).fetchall()
    return [dict(r) for r in rows]


def review_verification(verification_id, worker_id, approve: bool, admin_note=""):
    """ADMIN ONLY. Sets Verified/Rejected status. Also re-evaluates the Trusted Worker badge."""
    status = "Verified" if approve else "Rejected"
    with get_db() as conn:
        conn.execute(
            "UPDATE worker_verification SET status = ?, reviewed_at = ?, admin_note = ? WHERE id = ?",
            (status, now(), admin_note, verification_id),
        )
        conn.execute(
            "UPDATE workers SET verification_status = ? WHERE user_id = ?",
            (status, worker_id),
        )
    _recompute_trusted_badge(worker_id)
    return True, f"Worker verification marked as {status}."


def _recompute_trusted_badge(worker_id):
    """Trusted Worker badge = configurable rule (min completed projects + min rating),
    and the worker must currently be Verified. Admin-controlled criteria, not automatic
    for every worker."""
    with get_db() as conn:
        completed = conn.execute(
            "SELECT COUNT(*) c FROM work_requests WHERE worker_id = ? AND status = 'Completed'",
            (worker_id,),
        ).fetchone()["c"]
        rating_row = conn.execute(
            "SELECT AVG(rating) a FROM reviews WHERE worker_id = ? AND is_hidden = 0",
            (worker_id,),
        ).fetchone()
        avg_rating = rating_row["a"] or 0
        verification_status = conn.execute(
            "SELECT verification_status FROM workers WHERE user_id = ?", (worker_id,)
        ).fetchone()["verification_status"]

        eligible = (
            verification_status == "Verified"
            and completed >= TRUSTED_WORKER_MIN_COMPLETED_PROJECTS
            and avg_rating >= TRUSTED_WORKER_MIN_RATING
        )
        conn.execute(
            "UPDATE workers SET is_trusted = ? WHERE user_id = ?",
            (1 if eligible else 0, worker_id),
        )
    return eligible


def recompute_trusted_badge(worker_id):
    """Public wrapper - call after a request is marked Completed or a review is added."""
    return _recompute_trusted_badge(worker_id)
