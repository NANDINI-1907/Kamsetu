"""
KaamSetu - Ratings & Reviews.
Only the customer of a COMPLETED request may leave one review for that request.
"""

from database import get_db, now
from utils.validation import clamp_rating


def can_review(request_id, customer_id):
    with get_db() as conn:
        req = conn.execute(
            "SELECT * FROM work_requests WHERE id = ? AND customer_id = ?",
            (request_id, customer_id),
        ).fetchone()
        if not req:
            return False, "Request not found."
        if req["status"] != "Completed":
            return False, "You can only review completed work."
        existing = conn.execute(
            "SELECT id FROM reviews WHERE request_id = ?", (request_id,)
        ).fetchone()
        if existing:
            return False, "You have already reviewed this request."
    return True, ""


def add_review(request_id, customer_id, worker_id, rating, comment):
    ok, msg = can_review(request_id, customer_id)
    if not ok:
        return False, msg

    rating = clamp_rating(rating)
    with get_db() as conn:
        conn.execute(
            """INSERT INTO reviews (request_id, customer_id, worker_id, rating, comment, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (request_id, customer_id, worker_id, rating, (comment or "").strip(), now()),
        )
    return True, "Thank you! Your review has been submitted."


def get_worker_reviews(worker_id, include_hidden=False):
    query = """SELECT r.*, u.name AS customer_name
               FROM reviews r JOIN users u ON u.id = r.customer_id
               WHERE r.worker_id = ?"""
    if not include_hidden:
        query += " AND r.is_hidden = 0"
    query += " ORDER BY r.created_at DESC"
    with get_db() as conn:
        rows = conn.execute(query, (worker_id,)).fetchall()
    return [dict(r) for r in rows]


def get_worker_rating_summary(worker_id):
    with get_db() as conn:
        row = conn.execute(
            """SELECT AVG(rating) AS avg_rating, COUNT(*) AS total_reviews
               FROM reviews WHERE worker_id = ? AND is_hidden = 0""",
            (worker_id,),
        ).fetchone()
    avg_rating = round(row["avg_rating"], 1) if row["avg_rating"] else 0.0
    return avg_rating, row["total_reviews"] or 0


def get_completed_projects_count(worker_id):
    with get_db() as conn:
        row = conn.execute(
            "SELECT COUNT(*) c FROM work_requests WHERE worker_id = ? AND status = 'Completed'",
            (worker_id,),
        ).fetchone()
    return row["c"] or 0


def flag_review(review_id):
    with get_db() as conn:
        conn.execute("UPDATE reviews SET is_flagged = 1 WHERE id = ?", (review_id,))
    return True


def hide_review(review_id, hide=True):
    with get_db() as conn:
        conn.execute("UPDATE reviews SET is_hidden = ? WHERE id = ?", (1 if hide else 0, review_id))
    return True


def get_all_reviews():
    with get_db() as conn:
        rows = conn.execute(
            """SELECT r.*, cu.name AS customer_name, wo.name AS worker_name
               FROM reviews r
               JOIN users cu ON cu.id = r.customer_id
               JOIN users wo ON wo.id = r.worker_id
               ORDER BY r.created_at DESC"""
        ).fetchall()
    return [dict(r) for r in rows]
