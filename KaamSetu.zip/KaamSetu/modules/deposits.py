"""
KaamSetu - Refundable Security Deposit ("₹200 Deposit").

Deliberately simple, per the spec:
- One deposit per user per role (customer/worker), tied to their FIRST
  booking/accepted project only.
- No penalty math, no partial deductions, no AI judgment calls.
- Payment is simulated (no real gateway) - a button flips status to "Paid".
- Full refund happens automatically once the linked request reaches a
  terminal status (Completed, Rejected, or Cancelled) - a genuine
  cancellation never costs the user anything.
"""

from database import get_db, now
from config import SECURITY_DEPOSIT_AMOUNT

TERMINAL_STATUSES = {"Completed", "Rejected", "Cancelled"}


def get_deposit_for_user(user_id, role):
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM security_deposits WHERE user_id = ? AND role = ?",
            (user_id, role),
        ).fetchone()
    return dict(row) if row else None


def ensure_deposit_requirement(user_id, role, request_id):
    """
    Called when a customer creates their first booking, or a worker accepts
    their first project. If this user (in this role) has no deposit on file
    yet, create one tied to this specific request - status 'Required'.
    Does nothing on any subsequent booking/project (deposit is one-time).
    """
    existing = get_deposit_for_user(user_id, role)
    if existing:
        return existing

    with get_db() as conn:
        conn.execute(
            """INSERT INTO security_deposits (user_id, role, request_id, amount, status, created_at, updated_at)
               VALUES (?, ?, ?, ?, 'Required', ?, ?)""",
            (user_id, role, request_id, SECURITY_DEPOSIT_AMOUNT, now(), now()),
        )
    return get_deposit_for_user(user_id, role)


def pay_deposit(user_id, role):
    """Simulated payment - no real gateway. Only moves 'Required' -> 'Paid'."""
    deposit = get_deposit_for_user(user_id, role)
    if not deposit:
        return False, "No deposit is required for this account."
    if deposit["status"] != "Required":
        return False, f"Deposit is already {deposit['status']}."
    with get_db() as conn:
        conn.execute(
            "UPDATE security_deposits SET status = 'Paid', updated_at = ? WHERE id = ?",
            (now(), deposit["id"]),
        )
    return True, "₹200 deposit paid (simulated)."


def refund_deposits_for_request(request_id):
    """
    Called whenever a work request reaches a terminal status (Completed,
    Rejected, or Cancelled). If that request is the one a customer's and/or
    worker's deposit is tied to, and the deposit was Paid, refund it in
    full - no deductions, no exceptions, regardless of which terminal
    status was reached (a genuine cancellation costs nothing).
    """
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM security_deposits WHERE request_id = ? AND status = 'Paid'",
            (request_id,),
        ).fetchall()
        for row in rows:
            conn.execute(
                "UPDATE security_deposits SET status = 'Refunded', updated_at = ? WHERE id = ?",
                (now(), row["id"]),
            )
    return len(rows)


def get_all_deposits_admin():
    """For the Admin dashboard: every deposit with the user's name/role and
    the current status of the booking/project it's tied to."""
    with get_db() as conn:
        rows = conn.execute(
            """SELECT sd.*, u.name AS user_name, wr.status AS request_status
               FROM security_deposits sd
               JOIN users u ON u.id = sd.user_id
               JOIN work_requests wr ON wr.id = sd.request_id
               ORDER BY sd.created_at DESC"""
        ).fetchall()
    return [dict(r) for r in rows]
