"""
KaamSetu - Worker Professional Profile.
This is the core USP of the platform: a LinkedIn-style professional portfolio
for every skilled worker (basic info, skills, experience, certificates,
portfolio projects, ratings, and verification status).
"""

import streamlit as st

from database import get_db, now
from config import CATEGORY_ICONS, DEFAULT_ICON, t
from modules.reviews import get_worker_rating_summary, get_worker_reviews, get_completed_projects_count
from utils.helpers import format_stars

# ---------------------------------------------------------------------------
# DATA ACCESS
# ---------------------------------------------------------------------------

def get_categories(active_only=True):
    with get_db() as conn:
        query = "SELECT * FROM categories"
        if active_only:
            query += " WHERE is_active = 1"
        query += " ORDER BY name ASC"
        rows = conn.execute(query).fetchall()
    return [dict(r) for r in rows]


def get_worker_full(worker_id):
    with get_db() as conn:
        row = conn.execute(
            """SELECT u.*, w.about, w.main_occupation, w.main_category_id, w.location AS worker_location,
                      w.service_location, w.rate_info, w.availability, w.verification_status, w.is_trusted,
                      c.name AS main_category_name
               FROM users u
               JOIN workers w ON w.user_id = u.id
               LEFT JOIN categories c ON c.id = w.main_category_id
               WHERE u.id = ?""",
            (worker_id,),
        ).fetchone()
    return dict(row) if row else None


def update_worker_basic(worker_id, about, main_occupation, main_category_id, worker_location,
                         service_location, rate_info):
    with get_db() as conn:
        conn.execute(
            """UPDATE workers SET about = ?, main_occupation = ?, main_category_id = ?,
               location = ?, service_location = ?, rate_info = ? WHERE user_id = ?""",
            (about, main_occupation, main_category_id, worker_location, service_location,
             rate_info, worker_id),
        )
    return True


def update_worker_photo(worker_id, photo_path):
    with get_db() as conn:
        conn.execute("UPDATE users SET profile_photo = ? WHERE id = ?", (photo_path, worker_id))


def update_worker_account_info(worker_id, name, phone):
    """Account-level settings (name/phone) - separate from the professional profile fields."""
    with get_db() as conn:
        conn.execute("UPDATE users SET name = ?, phone = ? WHERE id = ?", (name, phone, worker_id))


def update_availability(worker_id, availability):
    with get_db() as conn:
        conn.execute("UPDATE workers SET availability = ? WHERE user_id = ?", (availability, worker_id))


def add_skill(worker_id, category_id, skill_name, years_experience):
    with get_db() as conn:
        conn.execute(
            "INSERT INTO worker_skills (worker_id, category_id, skill_name, years_experience) VALUES (?, ?, ?, ?)",
            (worker_id, category_id, skill_name.strip(), years_experience),
        )


def get_skills(worker_id):
    with get_db() as conn:
        rows = conn.execute(
            """SELECT ws.*, c.name AS category_name FROM worker_skills ws
               LEFT JOIN categories c ON c.id = ws.category_id
               WHERE ws.worker_id = ? ORDER BY ws.years_experience DESC""",
            (worker_id,),
        ).fetchall()
    return [dict(r) for r in rows]


def delete_skill(skill_id, worker_id):
    with get_db() as conn:
        conn.execute("DELETE FROM worker_skills WHERE id = ? AND worker_id = ?", (skill_id, worker_id))


def total_experience_years(worker_id):
    skills = get_skills(worker_id)
    if not skills:
        return 0
    return max(s["years_experience"] or 0 for s in skills)


def add_experience(worker_id, title, organization, description, start_date, end_date):
    with get_db() as conn:
        conn.execute(
            """INSERT INTO worker_experience (worker_id, title, organization, description, start_date, end_date)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (worker_id, title.strip(), organization, description, str(start_date), str(end_date) if end_date else None),
        )


def get_experience(worker_id):
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM worker_experience WHERE worker_id = ? ORDER BY start_date DESC", (worker_id,)
        ).fetchall()
    return [dict(r) for r in rows]


def delete_experience(exp_id, worker_id):
    with get_db() as conn:
        conn.execute("DELETE FROM worker_experience WHERE id = ? AND worker_id = ?", (exp_id, worker_id))


def add_certificate(worker_id, name, organization, year, file_path):
    with get_db() as conn:
        conn.execute(
            """INSERT INTO certificates (worker_id, name, organization, year, file_path, uploaded_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (worker_id, name.strip(), organization, year, file_path, now()),
        )


def get_certificates(worker_id):
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM certificates WHERE worker_id = ? ORDER BY uploaded_at DESC", (worker_id,)
        ).fetchall()
    return [dict(r) for r in rows]


def delete_certificate(cert_id, worker_id):
    with get_db() as conn:
        conn.execute("DELETE FROM certificates WHERE id = ? AND worker_id = ?", (cert_id, worker_id))


def add_portfolio_project(worker_id, title, description, category_id, location, project_date,
                           video_path, photo_paths):
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO portfolio_projects
               (worker_id, title, description, category_id, location, project_date, video_path, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (worker_id, title.strip(), description, category_id, location, str(project_date), video_path, now()),
        )
        project_id = cur.lastrowid
        for p in photo_paths:
            conn.execute(
                "INSERT INTO portfolio_media (project_id, file_path, media_type) VALUES (?, ?, 'photo')",
                (project_id, p),
            )
    return project_id


def get_portfolio_projects(worker_id):
    with get_db() as conn:
        projects = conn.execute(
            """SELECT pp.*, c.name AS category_name FROM portfolio_projects pp
               LEFT JOIN categories c ON c.id = pp.category_id
               WHERE pp.worker_id = ? ORDER BY pp.created_at DESC""",
            (worker_id,),
        ).fetchall()
        result = []
        for p in projects:
            p = dict(p)
            media = conn.execute(
                "SELECT * FROM portfolio_media WHERE project_id = ?", (p["id"],)
            ).fetchall()
            p["media"] = [dict(m) for m in media]
            result.append(p)
    return result


def delete_portfolio_project(project_id, worker_id):
    with get_db() as conn:
        conn.execute("DELETE FROM portfolio_projects WHERE id = ? AND worker_id = ?", (project_id, worker_id))


# ---------------------------------------------------------------------------
# RENDERING HELPERS (shared between customer search results and worker's own view)
# ---------------------------------------------------------------------------

def verification_badge_html(status, is_trusted, lang="en"):
    if is_trusted:
        return '<span class="badge badge-trusted">🏆 ' + t("trusted_worker_badge", lang) + '</span>'
    if status == "Verified":
        return '<span class="badge badge-verified">✅ ' + t("verified", lang) + '</span>'
    if status == "Pending":
        return '<span class="badge badge-pending">⏳ ' + t("pending_verification", lang) + '</span>'
    return '<span class="badge badge-unverified">⚪ ' + t("not_verified", lang) + '</span>'


def render_worker_card(worker, lang="en", show_match=False, key_prefix=""):
    """Renders a single worker profile card. `worker` is a dict from search results."""
    icon = CATEGORY_ICONS.get(worker.get("main_category_name"), DEFAULT_ICON)
    avg_rating, total_reviews = get_worker_rating_summary(worker["id"])
    stars = format_stars(avg_rating)

    with st.container(border=True):
        cols = st.columns([1, 3])
        with cols[0]:
            if worker.get("profile_photo"):
                try:
                    st.image(worker["profile_photo"], width=100)
                except Exception:
                    st.markdown(f"<div style='font-size:60px;text-align:center'>{icon}</div>", unsafe_allow_html=True)
            else:
                st.markdown(f"<div style='font-size:60px;text-align:center'>{icon}</div>", unsafe_allow_html=True)
        with cols[1]:
            st.markdown(f"### {worker['name']}")
            st.markdown(verification_badge_html(worker.get("verification_status"), worker.get("is_trusted"), lang),
                        unsafe_allow_html=True)
            st.markdown(f"**{icon} {worker.get('main_occupation') or worker.get('main_category_name') or '—'}**")
            st.caption(f"📍 {worker.get('worker_location') or worker.get('location') or 'Location not set'}  |  "
                       f"🧭 {worker.get('availability', 'Available')}")
            st.markdown(f"{stars}  ({avg_rating} · {total_reviews} reviews)")
            if worker.get("about"):
                about = worker["about"]
                st.write(about[:140] + ("..." if len(about) > 140 else ""))
            if show_match and worker.get("match_score") is not None:
                st.progress(min(100, worker["match_score"]) / 100.0,
                            text=f"{worker['match_score']}% {t('match_score', lang)}")
                if worker.get("match_reasons"):
                    st.caption(f"**{t('why_this_worker_matches', lang)}:** " +
                               " · ".join(f"✓ {r}" for r in worker["match_reasons"]))

        b1, b2 = st.columns(2)
        with b1:
            if st.button(f"👁️ {t('view_profile', lang)}", key=f"{key_prefix}view_{worker['id']}", use_container_width=True):
                st.session_state["selected_worker_id"] = worker["id"]
                st.session_state["customer_page"] = "worker_profile"
                st.rerun()
        with b2:
            if st.button(f"📩 {t('book_worker', lang)}", key=f"{key_prefix}req_{worker['id']}", use_container_width=True):
                st.session_state["selected_worker_id"] = worker["id"]
                st.session_state["customer_page"] = "request_work"
                st.rerun()


def render_full_profile(worker_id, lang="en", viewer_role="customer"):
    """Renders the complete professional profile / portfolio page for a worker."""
    worker = get_worker_full(worker_id)
    if not worker:
        st.error("Worker profile not found.")
        return

    icon = CATEGORY_ICONS.get(worker.get("main_category_name"), DEFAULT_ICON)
    avg_rating, total_reviews = get_worker_rating_summary(worker_id)
    completed = get_completed_projects_count(worker_id)

    st.markdown("## 👤 Professional Profile")
    top = st.columns([1, 2.5])
    with top[0]:
        if worker.get("profile_photo"):
            try:
                st.image(worker["profile_photo"], width=180)
            except Exception:
                st.markdown(f"<div style='font-size:100px'>{icon}</div>", unsafe_allow_html=True)
        else:
            st.markdown(f"<div style='font-size:100px'>{icon}</div>", unsafe_allow_html=True)
    with top[1]:
        st.markdown(f"# {worker['name']}")
        st.markdown(verification_badge_html(worker.get("verification_status"), worker.get("is_trusted"), lang),
                    unsafe_allow_html=True)
        st.markdown(f"**{icon} {worker.get('main_occupation') or worker.get('main_category_name') or 'Skilled Worker'}**")
        st.caption(f"📍 {worker.get('worker_location') or 'Location not set'}   |   "
                   f"🧭 Service area: {worker.get('service_location') or '—'}")
        st.markdown(f"{format_stars(avg_rating)}  **{avg_rating}** ({total_reviews} reviews)  ·  "
                    f"✅ {completed} projects completed")
        if worker.get("rate_info"):
            st.caption(f"💰 {worker['rate_info']}")
        st.markdown(f"🟢 Availability: **{worker.get('availability', 'Available')}**")

    if worker.get("about"):
        st.markdown(f"#### {t('about', lang)}")
        st.write(worker["about"])

    tabs = st.tabs([f"🧠 {t('skills', lang)}", f"💼 {t('experience', lang)}", f"📜 {t('certificates', lang)}",
                    f"🖼️ {t('portfolio', lang)}", f"⭐ {t('reviews', lang)}"])

    with tabs[0]:
        skills = get_skills(worker_id)
        if not skills:
            st.info(t("no_skills_yet", lang))
        else:
            for s in skills:
                st.markdown(f"- **{s['skill_name']}** ({s.get('category_name') or 'General'}) "
                            f"— {s['years_experience']} yrs experience")

    with tabs[1]:
        exp = get_experience(worker_id)
        if not exp:
            st.info(t("no_experience_yet", lang))
        else:
            for e in exp:
                end = e["end_date"] or "Present"
                st.markdown(f"**{e['title']}** at {e.get('organization') or '—'}  \n"
                            f"_{e['start_date']} → {end}_")
                if e.get("description"):
                    st.write(e["description"])
                st.divider()

    with tabs[2]:
        certs = get_certificates(worker_id)
        if not certs:
            st.info(t("no_certificates", lang))
        else:
            cert_cols = st.columns(3)
            for i, c in enumerate(certs):
                with cert_cols[i % 3]:
                    with st.container(border=True):
                        if c.get("file_path") and c["file_path"].lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
                            try:
                                st.image(c["file_path"], use_container_width=True)
                            except Exception:
                                st.markdown("📄")
                        else:
                            st.markdown("📄 Document")
                        st.markdown(f"**{c['name']}**")
                        st.caption(f"{c.get('organization') or ''} · {c.get('year') or ''}")

    with tabs[3]:
        projects = get_portfolio_projects(worker_id)
        if not projects:
            st.info(t("no_portfolio", lang))
        else:
            for p in projects:
                with st.container(border=True):
                    st.markdown(f"### {p['title']}")
                    st.caption(f"{p.get('category_name') or ''} · 📍 {p.get('location') or '—'} · {p.get('project_date') or ''}")
                    if p.get("description"):
                        st.write(p["description"])
                    if p.get("media"):
                        media_cols = st.columns(min(4, len(p["media"])))
                        for i, m in enumerate(p["media"]):
                            with media_cols[i % len(media_cols)]:
                                try:
                                    st.image(m["file_path"], use_container_width=True)
                                except Exception:
                                    pass
                    if p.get("video_path"):
                        try:
                            st.video(p["video_path"])
                        except Exception:
                            pass

    with tabs[4]:
        reviews = get_worker_reviews(worker_id)
        if not reviews:
            st.info(t("no_reviews", lang))
        else:
            for r in reviews:
                st.markdown(f"**{format_stars(r['rating'])}** — {r['customer_name']}")
                if r.get("comment"):
                    st.write(r["comment"])
                st.caption(r["created_at"])
                st.divider()
