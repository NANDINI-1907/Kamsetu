"""KaamSetu - Customer module: profile, worker search, Smart Matching, work requests, reviews."""

import streamlit as st

from database import get_db
from config import t, CATEGORY_ICONS, DEFAULT_ICON, PROFILE_UPLOAD_DIR, AVAILABILITY_STATES
from utils.helpers import save_uploaded_file, geocode_location
from utils.validation import non_empty
from modules.profile import get_categories, render_worker_card, render_full_profile, get_worker_full
from modules.matching import rank_workers, has_strong_match
from modules.requests import create_request, get_customer_requests, cancel_request
from modules.reviews import add_review
from modules.deposits import get_deposit_for_user, pay_deposit
from auth import change_password


# ---------------------------------------------------------------------------
# DATA ACCESS
# ---------------------------------------------------------------------------

def get_customer_profile(user_id):
    with get_db() as conn:
        row = conn.execute(
            """SELECT u.*, c.location FROM users u
               JOIN customers c ON c.user_id = u.id WHERE u.id = ?""",
            (user_id,),
        ).fetchone()
    return dict(row) if row else None


def update_customer_profile(user_id, name, phone, location):
    with get_db() as conn:
        conn.execute("UPDATE users SET name = ?, phone = ? WHERE id = ?", (name, phone, user_id))
        conn.execute("UPDATE customers SET location = ? WHERE user_id = ?", (location, user_id))


def search_workers(category_id=None, skill_text=None, location_text=None, min_experience=0,
                    min_rating=0, verified_only=False):
    """Search + filter workers, returning enriched rows with rating & experience data."""
    query = """
        SELECT u.id, u.name, u.profile_photo, w.about, w.main_occupation, w.main_category_id,
               w.location, w.location AS worker_location, w.service_location, w.rate_info,
               w.availability, w.verification_status, w.is_trusted,
               cat.name AS main_category_name,
               COALESCE(AVG(r.rating), 0) AS avg_rating,
               COUNT(DISTINCT r.id) AS total_reviews,
               COALESCE(MAX(ws.years_experience), 0) AS total_experience,
               MAX(CASE WHEN ws.category_id = ? THEN 1 ELSE 0 END) AS has_skill_in_category,
               (SELECT COUNT(*) FROM work_requests wr WHERE wr.worker_id = u.id AND wr.status = 'Completed') AS completed_projects
        FROM users u
        JOIN workers w ON w.user_id = u.id
        LEFT JOIN categories cat ON cat.id = w.main_category_id
        LEFT JOIN reviews r ON r.worker_id = u.id AND r.is_hidden = 0
        LEFT JOIN worker_skills ws ON ws.worker_id = u.id
        WHERE u.is_active = 1
    """
    params = [category_id]

    if category_id:
        query += " AND (w.main_category_id = ? OR ws.category_id = ?)"
        params += [category_id, category_id]
    if skill_text:
        query += " AND (ws.skill_name LIKE ? OR w.main_occupation LIKE ?)"
        like = f"%{skill_text}%"
        params += [like, like]
    if location_text:
        query += " AND (w.location LIKE ? OR w.service_location LIKE ?)"
        like = f"%{location_text}%"
        params += [like, like]
    if verified_only:
        query += " AND w.verification_status = 'Verified'"

    query += " GROUP BY u.id"
    query += " HAVING avg_rating >= ? AND total_experience >= ?"
    params += [min_rating, min_experience]

    with get_db() as conn:
        rows = conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


def _derive_customer_notifications(user_id):
    """Notifications are derived from existing tables (work request status changes) -
    no schema change needed. Sorted most-recent first."""
    with get_db() as conn:
        rows = conn.execute(
            """SELECT wr.id, wr.status, wr.updated_at, u.name AS worker_name, c.name AS category_name
               FROM work_requests wr
               JOIN users u ON u.id = wr.worker_id
               LEFT JOIN categories c ON c.id = wr.category_id
               WHERE wr.customer_id = ?
               ORDER BY wr.updated_at DESC
               LIMIT 25""",
            (user_id,),
        ).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# UI RENDERING
# ---------------------------------------------------------------------------

def render_customer_dashboard(user, lang):
    st.markdown(f"## 👋 {t('welcome_comma', lang)}, {user['name']}")

    st.session_state.setdefault("customer_page", "find_workers")

    nav_defs = [
        ("find_workers", "🔍", "find_a_worker"),
        ("smart_matching", "✨", "smart_matching"),
        ("my_profile", "🧾", "my_profile"),
        ("my_requests", "📋", "my_requests"),
        ("notifications", "🔔", "notifications"),
        ("settings", "⚙️", "settings"),
    ]
    nav = st.columns(len(nav_defs))
    for i, (key, icon, label_key) in enumerate(nav_defs):
        with nav[i]:
            if st.button(f"{icon} {t(label_key, lang)}", use_container_width=True,
                         type="primary" if st.session_state["customer_page"] == key else "secondary",
                         key=f"cust_nav_{key}"):
                st.session_state["customer_page"] = key
                st.rerun()

    st.divider()
    page = st.session_state["customer_page"]

    # Every valid customer sub-page is routed here explicitly; anything
    # unexpected falls back to the default "find_workers" view instead of
    # rendering a blank page.
    if page == "find_workers":
        _render_find_workers(user, lang)
    elif page == "smart_matching":
        _render_smart_matching(user, lang)
    elif page == "my_profile":
        _render_my_profile(user, lang)
    elif page == "my_requests":
        _render_my_requests(user, lang)
    elif page == "notifications":
        _render_notifications(user, lang)
    elif page == "settings":
        _render_settings(user, lang)
    elif page == "worker_profile":
        _render_worker_profile_page(user, lang)
    elif page == "request_work":
        _render_request_work_form(user, lang)
    else:
        st.session_state["customer_page"] = "find_workers"
        _render_find_workers(user, lang)


def _render_my_profile(user, lang):
    st.markdown(f"### 🧾 {t('my_profile', lang)}")
    profile = get_customer_profile(user["id"])
    col1, col2 = st.columns([1, 2])
    with col1:
        if profile.get("profile_photo"):
            try:
                st.image(profile["profile_photo"], width=150)
            except Exception:
                st.markdown("👤", unsafe_allow_html=True)
        photo = st.file_uploader("Update profile photo", type=["jpg", "jpeg", "png", "webp"], key="cust_photo")
        if photo and st.button(f"{t('upload', lang)} Photo", key="cust_upload_photo_btn"):
            ok, result = save_uploaded_file(photo, PROFILE_UPLOAD_DIR, "image")
            if ok:
                with get_db() as conn:
                    conn.execute("UPDATE users SET profile_photo = ? WHERE id = ?", (result, user["id"]))
                st.success("Profile photo updated!")
                st.rerun()
            else:
                st.error(result)
    with col2:
        with st.form("customer_profile_form"):
            name = st.text_input(t("name", lang), value=profile.get("name", ""))
            st.text_input(t("email", lang), value=profile.get("email", ""), disabled=True)
            phone = st.text_input(t("phone", lang), value=profile.get("phone", ""))
            location = st.text_input(t("location", lang), value=profile.get("location", "") or "")
            if st.form_submit_button(t("save", lang), key="customer_profile_save_btn"):
                if not non_empty(name) or not non_empty(phone):
                    st.error("Name and phone cannot be empty.")
                else:
                    update_customer_profile(user["id"], name.strip(), phone.strip(), location.strip())
                    st.session_state["user"]["name"] = name.strip()
                    st.success("Profile updated successfully!")
                    st.rerun()


def _render_find_workers(user, lang):
    st.markdown(f"### 🔍 {t('find_a_worker', lang)}")
    categories = get_categories()
    cat_names = [t("all_categories", lang)] + [c["name"] for c in categories]

    with st.container(border=True):
        c1, c2, c3 = st.columns(3)
        with c1:
            cat_choice = st.selectbox(t("worker_categories", lang), cat_names, key="find_cat")
        with c2:
            skill_text = st.text_input(t("skills", lang), placeholder="e.g. wiring, tap repair", key="find_skill")
        with c3:
            location_text = st.text_input(t("location", lang), placeholder="e.g. Hyderabad", key="find_loc")

        c4, c5, c6 = st.columns(3)
        with c4:
            min_experience = st.slider(f"Min {t('experience', lang)} (yrs)", 0, 20, 0, key="find_exp")
        with c5:
            min_rating = st.slider(f"Min {t('rating', lang)}", 0.0, 5.0, 0.0, step=0.5, key="find_rating")
        with c6:
            verified_only = st.checkbox(f"Only {t('verified', lang)}", key="find_verified")

    category_id = None
    if cat_choice != t("all_categories", lang):
        category_id = next((c["id"] for c in categories if c["name"] == cat_choice), None)

    results = search_workers(category_id, skill_text, location_text, min_experience, min_rating, verified_only)

    st.markdown(f"**{len(results)} {t('workers_found', lang)}**")
    if not results:
        st.info(t("no_workers_found", lang))
        return

    for w in results:
        render_worker_card(w, lang, key_prefix="find_")


def _render_smart_matching(user, lang):
    st.markdown(f"### ✨ {t('smart_matching', lang)}")
    st.caption("This is a transparent, rule-based ranking (not advanced AI): skill match, location, "
               "experience, availability, rating, completed projects, and budget compatibility.")

    categories = get_categories()
    cat_names = [t("any_category", lang)] + [c["name"] for c in categories]
    customer_profile = get_customer_profile(user["id"])

    with st.form("smart_matching_form"):
        r1c1, r1c2 = st.columns(2)
        with r1c1:
            cat_choice = st.selectbox(t("work_category", lang), cat_names, key="sm_cat")
        with r1c2:
            skill_text = st.text_input(t("required_skill", lang), placeholder="e.g. house wiring", key="sm_skill")

        r2c1, r2c2 = st.columns(2)
        with r2c1:
            location_text = st.text_input(t("location", lang), key="sm_loc",
                                           value=customer_profile.get("location") or "")
        with r2c2:
            min_experience = st.number_input(t("min_experience_required", lang), min_value=0, max_value=30,
                                              value=0, step=1, key="sm_exp")

        r3c1, r3c2 = st.columns(2)
        with r3c1:
            budget_min, budget_max = st.slider(t("budget_range", lang), 0, 20000, (500, 3000), step=100, key="sm_budget")
        with r3c2:
            availability_options = ["Today", "Any"]
            preferred_availability = st.selectbox(t("preferred_availability", lang), availability_options, key="sm_avail")

        urgency = st.select_slider(t("urgency", lang), options=["Low", "Medium", "High"], value="Medium", key="sm_urgency")
        description = st.text_area(t("work_description_optional", lang), key="sm_desc")

        submitted = st.form_submit_button(f"🔎 {t('find_best_matches', lang)}", type="primary", use_container_width=True,
                                           key="smart_match_btn")

    if not submitted and "sm_last_results" not in st.session_state:
        return

    if submitted:
        category_id = None
        if cat_choice != t("any_category", lang):
            category_id = next((c["id"] for c in categories if c["name"] == cat_choice), None)

        customer_lat, customer_lon = (None, None)
        if location_text:
            customer_lat, customer_lon = geocode_location(location_text)

        results = search_workers(category_id, skill_text or None, None, 0, 0, False)
        ranked = rank_workers(
            results, search_category_id=category_id, customer_lat=customer_lat, customer_lon=customer_lon,
            min_experience_required=min_experience, preferred_availability=preferred_availability,
            budget_min=budget_min, budget_max=budget_max, location_text=location_text,
            urgency=urgency,
        )
        st.session_state["sm_last_results"] = ranked

    ranked = st.session_state.get("sm_last_results", [])

    if not ranked:
        st.info(t("no_workers_found", lang))
        return

    st.markdown(f"#### 🏆 {t('best_matches_for_you', lang)}")

    if not has_strong_match(ranked):
        st.warning(f"⚠️ {t('no_exact_match_found', lang)}")
        st.caption(t("closest_available_workers", lang))
        with st.container(border=True):
            st.markdown(f"**💡 {t('suggestions', lang)}:**")
            st.markdown(f"- {t('expand_location', lang)}")
            st.markdown(f"- {t('increase_budget', lang)}")
            st.markdown(f"- {t('choose_other_availability', lang)}")
            st.markdown(f"- {t('select_related_skills', lang)}")

    for w in ranked[:15]:
        render_worker_card(w, lang, show_match=True, key_prefix="sm_")


def _render_worker_profile_page(user, lang):
    worker_id = st.session_state.get("selected_worker_id")
    if st.button(f"⬅️ {t('back', lang)}", key="wp_back_btn"):
        st.session_state["customer_page"] = "find_workers"
        st.rerun()
    if not worker_id:
        st.warning("No worker selected.")
        return
    render_full_profile(worker_id, lang, viewer_role="customer")
    st.divider()
    if st.button(f"📩 {t('request_work', lang)}", type="primary", key="wp_request_work_btn"):
        st.session_state["customer_page"] = "request_work"
        st.rerun()


def _render_request_work_form(user, lang):
    worker_id = st.session_state.get("selected_worker_id")
    if st.button(f"⬅️ {t('back', lang)}", key="rw_back_btn"):
        st.session_state["customer_page"] = "worker_profile"
        st.rerun()
    if not worker_id:
        st.warning("No worker selected.")
        return

    worker = get_worker_full(worker_id)
    if not worker:
        st.error("Worker not found.")
        return

    icon = CATEGORY_ICONS.get(worker.get("main_category_name"), DEFAULT_ICON)
    st.markdown(f"### {icon} {t('request_work', lang)} — {worker['name']}")

    categories = get_categories()
    cat_names = [c["name"] for c in categories]
    default_index = 0
    if worker.get("main_category_name") in cat_names:
        default_index = cat_names.index(worker["main_category_name"])

    with st.form("request_work_form"):
        category_choice = st.selectbox(t("work_category", lang), cat_names, index=default_index)
        description = st.text_area(t("description", lang), placeholder="Describe what needs to be done...")
        location = st.text_input(t("location", lang), value=get_customer_profile(user["id"]).get("location") or "")
        c1, c2 = st.columns(2)
        with c1:
            preferred_date = st.date_input("Preferred date")
        with c2:
            preferred_time = st.time_input("Preferred time")
        additional = st.text_area("Additional requirements (optional)")

        submitted = st.form_submit_button(t("submit", lang), type="primary", key="request_work_submit_btn")
        if submitted:
            if not non_empty(description) or not non_empty(location):
                st.error("Please fill in the work description and location.")
            else:
                category_id = next((c["id"] for c in categories if c["name"] == category_choice), None)
                ok, msg = create_request(user["id"], worker_id, category_id, description.strip(),
                                          location.strip(), preferred_date, preferred_time, additional.strip())
                if ok:
                    st.success(msg)
                    st.session_state["customer_page"] = "my_requests"
                    st.rerun()
                else:
                    st.error(msg)


def _render_deposit_badge(deposit, lang, role, key_prefix, on_paid_rerun=True):
    """Small, reusable ₹200 refundable-deposit status block.
    Shown to whichever user (customer/worker) the deposit belongs to."""
    if not deposit:
        return
    status = deposit["status"]
    if status == "Required":
        st.warning(f"🔒 {t('deposit_required', lang)}")
        st.caption(t("deposit_note", lang))
        if st.button(f"💳 {t('pay_deposit_button', lang)}", key=f"{key_prefix}pay_deposit_btn"):
            ok, msg = pay_deposit(deposit["user_id"], role)
            if ok:
                st.success(msg)
                if on_paid_rerun:
                    st.rerun()
            else:
                st.error(msg)
    elif status == "Paid":
        st.info(f"🔒 {t('deposit_paid', lang)} (₹{deposit['amount']})")
    elif status == "Refunded":
        st.success(f"🔒 {t('refund_processed', lang)}")


def _render_my_requests(user, lang):
    st.markdown(f"### 📋 {t('my_requests', lang)}")
    requests = get_customer_requests(user["id"])
    if not requests:
        st.info(t("no_requests_yet", lang))
        return

    deposit = get_deposit_for_user(user["id"], "customer")

    status_colors = {
        "Pending": "🟡", "Accepted": "🔵", "In Progress": "🟠",
        "Completed": "🟢", "Rejected": "🔴", "Cancelled": "⚫",
    }
    status_key_map = {
        "Pending": "status_pending", "Accepted": "status_accepted", "In Progress": "status_in_progress",
        "Completed": "status_completed", "Rejected": "status_rejected", "Cancelled": "status_cancelled",
    }

    for r in requests:
        with st.container(border=True):
            status_label = t(status_key_map.get(r["status"], "status_pending"), lang)
            st.markdown(f"**{status_colors.get(r['status'], '')} {status_label}** — "
                        f"{r.get('category_name') or 'Service'} with **{r['worker_name']}**")
            st.caption(f"📍 {r['location']} · 📅 {r['preferred_date']} {r['preferred_time']}")
            st.write(r["description"])

            # This is the specific booking the customer's one-time ₹200
            # refundable deposit is tied to (if any) - show its status here.
            if deposit and deposit["request_id"] == r["id"]:
                _render_deposit_badge(deposit, lang, "customer", key_prefix=f"myreq_{r['id']}_")

            if r["status"] == "Pending":
                if st.button("Cancel Request", key=f"cancel_{r['id']}"):
                    ok, msg = cancel_request(r["id"], user["id"])
                    st.success(msg) if ok else st.error(msg)
                    st.rerun()
            if r["status"] == "Completed" and not r["has_review"]:
                with st.expander(f"⭐ Rate & Review this work"):
                    rating = st.slider(t("rating", lang), 1, 5, 5, key=f"rating_{r['id']}")
                    comment = st.text_area("Your review", key=f"comment_{r['id']}")
                    if st.button("Submit Review", key=f"submit_review_{r['id']}"):
                        ok, msg = add_review(r["id"], user["id"], r["worker_id"], rating, comment)
                        if ok:
                            from modules.verification import recompute_trusted_badge
                            recompute_trusted_badge(r["worker_id"])
                            st.success(msg)
                            st.rerun()
                        else:
                            st.error(msg)
            elif r["status"] == "Completed" and r["has_review"]:
                st.caption("✅ You've already reviewed this request.")


def _render_notifications(user, lang):
    st.markdown(f"### 🔔 {t('notifications', lang)}")
    notifications = _derive_customer_notifications(user["id"])
    if not notifications:
        st.info(t("no_notifications", lang))
        return

    status_key_map = {
        "Pending": "status_pending", "Accepted": "status_accepted", "In Progress": "status_in_progress",
        "Completed": "status_completed", "Rejected": "status_rejected", "Cancelled": "status_cancelled",
    }
    status_icons = {
        "Pending": "🟡", "Accepted": "✅", "In Progress": "🚧",
        "Completed": "🏁", "Rejected": "❌", "Cancelled": "⚫",
    }
    for n in notifications:
        icon = status_icons.get(n["status"], "🔔")
        status_label = t(status_key_map.get(n["status"], "status_pending"), lang)
        with st.container(border=True):
            st.markdown(f"{icon} Your request for **{n.get('category_name') or 'a service'}** with "
                        f"**{n['worker_name']}** is now **{status_label}**")
            st.caption(n["updated_at"])


def _render_settings(user, lang):
    st.markdown(f"### ⚙️ {t('settings', lang)}")
    profile = get_customer_profile(user["id"])

    st.markdown(f"#### {t('account_info', lang)}")
    st.write(f"**{t('name', lang)}:** {profile.get('name')}")
    st.write(f"**{t('email', lang)}:** {profile.get('email')}")
    st.write(f"**{t('phone', lang)}:** {profile.get('phone')}")

    st.divider()
    st.markdown(f"#### 🔒 {t('security_deposit', lang)}")
    deposit = get_deposit_for_user(user["id"], "customer")
    if not deposit:
        st.caption(t("no_deposit_required_yet", lang))
    else:
        _render_deposit_badge(deposit, lang, "customer", key_prefix="settings_")

    st.divider()
    st.markdown(f"#### {t('change_password', lang)}")
    with st.form("customer_change_password_form"):
        current_password = st.text_input(t("current_password", lang), type="password")
        new_password = st.text_input(t("new_password", lang), type="password")
        confirm_new_password = st.text_input(t("confirm_new_password", lang), type="password")
        if st.form_submit_button(t("change_password", lang), type="primary", key="customer_change_password_btn"):
            if new_password != confirm_new_password:
                st.error("New passwords do not match.")
            else:
                ok, msg = change_password(user["id"], current_password, new_password)
                if ok:
                    st.success(t("password_changed", lang))
                else:
                    st.error(msg)
