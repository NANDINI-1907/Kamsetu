"""Security helpers: password hashing and role guards."""

import bcrypt
import streamlit as st


def hash_password(plain_password: str) -> str:
    return bcrypt.hashpw(plain_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain_password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(plain_password.encode("utf-8"), password_hash.encode("utf-8"))
    except Exception:
        return False


def current_user():
    return st.session_state.get("user")


def require_role(role: str) -> bool:
    """Return True if the logged-in user has the given role. Does not stop execution."""
    user = current_user()
    return bool(user) and user["role"] == role


def is_logged_in() -> bool:
    return st.session_state.get("user") is not None
