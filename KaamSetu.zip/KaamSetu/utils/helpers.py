"""Misc helpers: safe file uploads, location distance, badge/rating utilities."""

import os
import uuid
from datetime import datetime

from config import (
    ALLOWED_IMAGE_TYPES, ALLOWED_DOC_TYPES, ALLOWED_VIDEO_TYPES,
    MAX_IMAGE_SIZE_MB, MAX_VIDEO_SIZE_MB, MAX_DOC_SIZE_MB,
)


def _ext(filename: str) -> str:
    return filename.rsplit(".", 1)[-1].lower() if "." in filename else ""


def save_uploaded_file(uploaded_file, target_dir: str, kind: str = "image"):
    """
    Safely save a Streamlit UploadedFile.
    kind: 'image' | 'doc' | 'video'
    Returns (success: bool, path_or_error: str)
    """
    if uploaded_file is None:
        return False, "No file provided."

    ext = _ext(uploaded_file.name)
    allowed = {"image": ALLOWED_IMAGE_TYPES, "doc": ALLOWED_DOC_TYPES, "video": ALLOWED_VIDEO_TYPES}[kind]
    max_mb = {"image": MAX_IMAGE_SIZE_MB, "doc": MAX_DOC_SIZE_MB, "video": MAX_VIDEO_SIZE_MB}[kind]

    if ext not in allowed:
        return False, f"Unsupported file type '.{ext}'. Allowed: {', '.join(allowed)}"

    size_mb = uploaded_file.size / (1024 * 1024)
    if size_mb > max_mb:
        return False, f"File too large ({size_mb:.1f} MB). Max allowed is {max_mb} MB."

    os.makedirs(target_dir, exist_ok=True)
    unique_name = f"{uuid.uuid4().hex}.{ext}"
    full_path = os.path.join(target_dir, unique_name)

    try:
        with open(full_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
    except Exception as e:
        return False, f"Could not save file: {e}"

    return True, full_path


def haversine_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in km. Returns None if any coordinate missing."""
    if None in (lat1, lon1, lat2, lon2):
        return None
    from math import radians, sin, cos, sqrt, atan2
    R = 6371.0
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)
    a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c


def geocode_location(location_text: str):
    """
    Attempt to geocode a location string using Geopy (Nominatim).
    Returns (lat, lon) or (None, None) on failure. Never raises - location
    functionality must remain optional.
    """
    if not location_text or not location_text.strip():
        return None, None
    try:
        from geopy.geocoders import Nominatim
        geolocator = Nominatim(user_agent="kaamsetu_app", timeout=3)
        loc = geolocator.geocode(location_text)
        if loc:
            return loc.latitude, loc.longitude
    except Exception:
        pass
    return None, None


def timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def format_stars(rating: float) -> str:
    if rating is None:
        return "☆☆☆☆☆"
    full = int(round(rating))
    full = max(0, min(5, full))
    return "⭐" * full + "☆" * (5 - full)
