"""Input validation helpers used across registration, profile, and request forms."""

import re


def is_valid_email(email: str) -> bool:
    if not email:
        return False
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return re.match(pattern, email.strip()) is not None


def is_valid_phone(phone: str) -> bool:
    if not phone:
        return False
    digits = re.sub(r"\D", "", phone)
    return 8 <= len(digits) <= 15


def is_strong_password(password: str) -> (bool, str):
    if not password or len(password) < 6:
        return False, "Password must be at least 6 characters long."
    return True, ""


def non_empty(value: str) -> bool:
    return value is not None and str(value).strip() != ""


def safe_str(value, default="") -> str:
    if value is None:
        return default
    return str(value)


def clamp_rating(value: int) -> int:
    try:
        v = int(value)
    except (TypeError, ValueError):
        return 5
    return max(1, min(5, v))
